import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import SearchSection from '@/components/sections/SearchSection';

const Travel = () => {
  return (
    <>
      <Helmet>
        <title>Travel Services - ATurneroundLife Travel LLC</title>
        <meta name="description" content="Explore our comprehensive travel services including cruises, hotels, resorts, and flights. Let us help you plan your perfect getaway." />
      </Helmet>
      <div className="pt-24 min-h-screen">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="container mx-auto px-4 py-12"
        >
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-white mb-6">Travel Services</h1>
            <p className="text-xl text-cyan-200 max-w-3xl mx-auto">
              Discover amazing destinations and create unforgettable memories with our comprehensive travel services.
            </p>
          </div>
          
          <SearchSection />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-16">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20"
            >
              <img alt="Luxury cruise ship at sunset" className="w-full h-48 object-cover rounded-lg mb-6" src="https://images.unsplash.com/photo-1633362165757-8a081dbb3336" />
              <h3 className="text-2xl font-bold text-white mb-4">Cruise Vacations</h3>
              <p className="text-cyan-200">Experience the ultimate luxury with our carefully selected cruise packages to exotic destinations worldwide.</p>
            </motion.div>
            
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20"
            >
              <img alt="Luxury resort with infinity pool" className="w-full h-48 object-cover rounded-lg mb-6" src="https://images.unsplash.com/photo-1651003829069-d11e7bbcb412" />
              <h3 className="text-2xl font-bold text-white mb-4">Resort Getaways</h3>
              <p className="text-cyan-200">Relax and unwind at world-class resorts offering premium amenities and breathtaking views.</p>
            </motion.div>
            
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20"
            >
              <img alt="Modern airplane in flight" className="w-full h-48 object-cover rounded-lg mb-6" src="https://images.unsplash.com/photo-1700138072872-34af402dd09a" />
              <h3 className="text-2xl font-bold text-white mb-4">Flight Bookings</h3>
              <p className="text-cyan-200">Find the best flight deals and enjoy comfortable travel to your dream destinations.</p>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Travel;