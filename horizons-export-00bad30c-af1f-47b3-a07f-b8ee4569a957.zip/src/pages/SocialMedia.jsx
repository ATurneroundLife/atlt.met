import React from 'react';
import { Helmet } from 'react-helmet';
import SocialSection from '@/components/sections/SocialSection';

const SocialMedia = () => {
  return (
    <>
      <Helmet>
        <title>Social Media - ATurneroundLife Travel LLC</title>
        <meta name="description" content="Follow ATurneroundLife Travel LLC on social media for travel inspiration, deals, and updates on amazing destinations worldwide." />
      </Helmet>
      <div className="pt-24">
        <SocialSection />
      </div>
    </>
  );
};

export default SocialMedia;