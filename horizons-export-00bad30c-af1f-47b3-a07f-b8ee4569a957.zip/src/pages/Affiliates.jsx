import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Building, Plane, Ship, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Affiliates = () => {
  const handlePartnerClick = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const partners = [
    {
      name: 'Global Airways',
      description: 'Fly in comfort and style with our trusted airline partner, offering exclusive deals for our clients.',
      icon: Plane,
      color: 'from-blue-400 to-blue-500',
    },
    {
      name: 'Luxury Cruise Lines',
      description: 'Sail the seven seas on magnificent ships with unparalleled service and breathtaking itineraries.',
      icon: Ship,
      color: 'from-cyan-400 to-teal-500',
    },
    {
      name: 'Exquisite Hotels Group',
      description: 'Stay at the world\'s most luxurious hotels and resorts, where every detail is crafted for your comfort.',
      icon: Building,
      color: 'from-purple-400 to-indigo-500',
    },
    {
      name: 'Adventure Tours Inc.',
      description: 'Embark on thrilling adventures and unique cultural experiences with our expert tour partner.',
      icon: Star,
      color: 'from-yellow-400 to-orange-500',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Our Partners - ATurneroundLife Travel LLC</title>
        <meta name="description" content="Discover our trusted partners in the travel industry. We collaborate with the best to provide you with exceptional travel experiences." />
      </Helmet>
      <div className="pt-24 min-h-screen">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="container mx-auto px-4 py-12"
        >
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-white mb-6">Our Trusted Partners</h1>
            <p className="text-xl text-cyan-200 max-w-3xl mx-auto">
              We collaborate with industry leaders to ensure you receive the highest quality service and unforgettable travel experiences.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {partners.map((partner, index) => (
              <motion.div
                key={partner.name}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 flex flex-col items-center text-center"
              >
                <div className={`w-20 h-20 rounded-full bg-gradient-to-r ${partner.color} flex items-center justify-center mb-6`}>
                  <partner.icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">{partner.name}</h3>
                <p className="text-cyan-200 leading-relaxed mb-6 flex-grow">{partner.description}</p>
                <Button 
                  onClick={handlePartnerClick}
                  className="bg-white/20 text-white hover:bg-white/30 px-6 py-2 rounded-full font-semibold transition-all duration-300"
                >
                  Learn More
                </Button>
              </motion.div>
            ))}
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-12 border border-white/20 text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Interested in Partnering With Us?</h2>
            <p className="text-xl text-cyan-200 mb-8 max-w-2xl mx-auto">
              If you share our passion for exceptional travel and customer service, we'd love to hear from you.
            </p>
            <Button 
              onClick={() => {
                const contactSection = document.getElementById('contact');
                if (contactSection) {
                  contactSection.scrollIntoView({ behavior: 'smooth' });
                } else {
                  window.location.href = '/#contact';
                }
              }}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-4 text-lg font-semibold rounded-full transform hover:scale-105 transition-all duration-300"
            >
              Contact Us
            </Button>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Affiliates;