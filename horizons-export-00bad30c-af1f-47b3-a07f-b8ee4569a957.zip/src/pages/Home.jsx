import React from 'react';
import { Helmet } from 'react-helmet';
import HeroSection from '@/components/sections/HeroSection';
import SearchSection from '@/components/sections/SearchSection';
import ServicesSection from '@/components/sections/ServicesSection';
import ConsultationSection from '@/components/sections/ConsultationSection';
import CompanySection from '@/components/sections/CompanySection';
import AffiliatesSection from '@/components/sections/AffiliatesSection';
import SocialSection from '@/components/sections/SocialSection';
import ContactSection from '@/components/sections/ContactSection';

const Home = () => {
  return (
    <>
      <Helmet>
        <title>ATurneroundLife Travel LLC - Your Gateway to Amazing Adventures</title>
        <meta name="description" content="Discover incredible travel experiences with ATurneroundLife Travel LLC. Book cruises, hotels, resorts, and flights with our expert travel consultation services." />
      </Helmet>
      <main>
        <HeroSection />
        <SearchSection />
        <ServicesSection />
        <ConsultationSection />
        <CompanySection />
        <AffiliatesSection />
        <SocialSection />
        <ContactSection />
      </main>
    </>
  );
};

export default Home;