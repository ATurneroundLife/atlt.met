import React from 'react';
import { Helmet } from 'react-helmet';
import ContactSection from '@/components/sections/ContactSection';

const Contact = () => {
  return (
    <>
      <Helmet>
        <title>Contact Us - ATurneroundLife Travel LLC</title>
        <meta name="description" content="Get in touch with ATurneroundLife Travel LLC for personalized travel consultation and booking services. We're here to help plan your perfect trip." />
      </Helmet>
      <div className="pt-24">
        <ContactSection />
      </div>
    </>
  );
};

export default Contact;