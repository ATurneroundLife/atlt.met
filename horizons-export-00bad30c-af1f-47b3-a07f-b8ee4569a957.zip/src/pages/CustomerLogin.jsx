import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { LogIn, User, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const CustomerLogin = () => {
  const handleLogin = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <>
      <Helmet>
        <title>Customer Login - ATurneroundLife Travel LLC</title>
        <meta name="description" content="Access your ATurneroundLife Travel LLC account to view your booking history and manage your travel plans." />
      </Helmet>
      <div className="pt-24 min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="container mx-auto px-4 py-12"
        >
          <div className="max-w-md mx-auto bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
            <div className="text-center mb-8">
              <LogIn className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
              <h1 className="text-4xl font-bold text-white mb-2">Customer Login</h1>
              <p className="text-cyan-200">Access your travel dashboard.</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/70" />
                <input
                  type="email"
                  placeholder="Email Address"
                  className="w-full pl-12 pr-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  required
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/70" />
                <input
                  type="password"
                  placeholder="Password"
                  className="w-full pl-12 pr-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  required
                />
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center space-x-2 text-white/80">
                  <input type="checkbox" className="form-checkbox h-4 w-4 bg-white/20 border-white/30 text-cyan-500 focus:ring-cyan-400" />
                  <span>Remember Me</span>
                </label>
                <a href="#" onClick={(e) => e.preventDefault()} className="text-cyan-300 hover:text-cyan-100 transition">Forgot Password?</a>
              </div>

              <Button 
                type="submit"
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white py-3 text-lg font-semibold rounded-lg transform hover:scale-105 transition-all duration-300"
              >
                <LogIn className="w-5 h-5 mr-2" />
                Sign In
              </Button>
            </form>
            
            <p className="text-center text-white/80 mt-6 text-sm">
              Don't have an account? <a href="#" onClick={(e) => e.preventDefault()} className="font-semibold text-cyan-300 hover:text-cyan-100 transition">Sign Up</a>
            </p>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default CustomerLogin;