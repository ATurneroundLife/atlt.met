import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Home from '@/pages/Home';
import Travel from '@/pages/Travel';
import Contact from '@/pages/Contact';
import SocialMedia from '@/pages/SocialMedia';
import Affiliates from '@/pages/Affiliates';
import CustomerLogin from '@/pages/CustomerLogin';
import Footer from '@/components/Footer';
import { Toaster } from '@/components/ui/toaster';
import FacebookMessengerChat from '@/components/FacebookMessengerChat';

function App() {
  const FACEBOOK_PAGE_ID = "100086778344616";

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-teal-800 to-cyan-900">
        <Helmet>
          <title>ATurneroundLife Travel LLC - Your Gateway to Amazing Adventures</title>
          <meta name="description" content="Discover incredible travel experiences with ATurneroundLife Travel LLC. Book cruises, hotels, resorts, and flights with our expert travel consultation services." />
        </Helmet>
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/travel" element={<Travel />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/social" element={<SocialMedia />} />
          <Route path="/affiliates" element={<Affiliates />} />
          <Route path="/customer-login" element={<CustomerLogin />} />
        </Routes>
        <Footer />
        <FacebookMessengerChat pageId={FACEBOOK_PAGE_ID} />
        <Toaster />
      </div>
    </Router>
  );
}

export default App;