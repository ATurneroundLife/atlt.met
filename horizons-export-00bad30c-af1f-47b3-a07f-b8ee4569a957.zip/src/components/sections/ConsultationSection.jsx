import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, Phone, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const ConsultationSection = () => {
  const handleBookConsultation = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const benefits = [
    {
      icon: Calendar,
      title: 'Flexible Scheduling',
      description: 'Book at your convenience with our flexible scheduling options.'
    },
    {
      icon: Clock,
      title: '30-Minute Sessions',
      description: 'Comprehensive consultation in just 30 minutes of your time.'
    },
    {
      icon: Phone,
      title: 'Multiple Formats',
      description: 'Choose from phone, video call, or in-person consultations.'
    },
    {
      icon: MessageCircle,
      title: 'Expert Advice',
      description: 'Get personalized recommendations from our travel experts.'
    }
  ];

  return (
    <section id="consultation" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/50 to-blue-900/50"></div>
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-white mb-6">Reserve Your Complimentary Consultation</h2>
          <p className="text-xl text-cyan-200 max-w-3xl mx-auto">
            Get personalized travel advice from our experts. Completely free, no obligations.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="grid sm:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
                >
                  <benefit.icon className="w-8 h-8 text-cyan-400 mb-4" />
                  <h3 className="text-lg font-bold text-white mb-2">{benefit.title}</h3>
                  <p className="text-cyan-200 text-sm">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20"
          >
            <h3 className="text-3xl font-bold text-white mb-6 text-center">Book Your Free Consultation</h3>
            <div className="space-y-4 mb-8">
              <input
                type="text"
                placeholder="Your Name"
                className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-cyan-400"
              />
              <input
                type="email"
                placeholder="Email Address"
                className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-cyan-400"
              />
              <input
                type="tel"
                placeholder="Phone Number"
                className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-cyan-400"
              />
              <select className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white focus:outline-none focus:ring-2 focus:ring-cyan-400">
                <option value="">Preferred Consultation Type</option>
                <option value="phone">Phone Call</option>
                <option value="video">Video Call</option>
                <option value="person">In-Person</option>
              </select>
            </div>
            <Button 
              onClick={handleBookConsultation}
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white py-4 text-lg font-semibold rounded-lg transform hover:scale-105 transition-all duration-300"
            >
              Reserve My Free Consultation
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ConsultationSection;