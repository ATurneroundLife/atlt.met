import React from 'react';
import { motion } from 'framer-motion';
import { Anchor, Plane, Building, MapPin, Star, Shield } from 'lucide-react';

const ServicesSection = () => {
  const services = [
    {
      icon: Anchor,
      title: 'Cruise Packages',
      description: 'Luxury cruise experiences to exotic destinations worldwide with premium amenities.',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Building,
      title: 'Hotel Bookings',
      description: 'Carefully selected hotels offering comfort, luxury, and exceptional service.',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: MapPin,
      title: 'Resort Getaways',
      description: 'All-inclusive resort packages for the ultimate relaxation and adventure.',
      color: 'from-green-500 to-teal-500'
    },
    {
      icon: Plane,
      title: 'Flight Services',
      description: 'Best flight deals and comfortable travel arrangements to any destination.',
      color: 'from-orange-500 to-red-500'
    },
    {
      icon: Star,
      title: 'VIP Experiences',
      description: 'Exclusive access to premium experiences and personalized travel services.',
      color: 'from-yellow-500 to-orange-500'
    },
    {
      icon: Shield,
      title: 'Travel Insurance',
      description: 'Comprehensive travel protection for peace of mind during your journey.',
      color: 'from-indigo-500 to-purple-500'
    }
  ];

  return (
    <section id="services" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-white mb-6">Our Services</h2>
          <p className="text-xl text-cyan-200 max-w-3xl mx-auto">
            We offer comprehensive travel services to make your dream vacation a reality.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 hover:border-white/40 transition-all duration-300"
            >
              <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${service.color} flex items-center justify-center mb-6`}>
                <service.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">{service.title}</h3>
              <p className="text-cyan-200 leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;