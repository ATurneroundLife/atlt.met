import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Calendar, MapPin, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const SearchSection = () => {
  const [activeTab, setActiveTab] = useState('cruise');

  const handleSearch = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const tabs = [
    { id: 'cruise', label: 'Cruises', icon: '🚢' },
    { id: 'hotel', label: 'Hotels', icon: '🏨' },
    { id: 'resort', label: 'Resorts', icon: '🏖️' },
    { id: 'flight', label: 'Flights', icon: '✈️' }
  ];

  return (
    <section id="search" className="py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20"
        >
          <h2 className="text-4xl font-bold text-white text-center mb-8">Find Your Perfect Trip</h2>
          
          {/* Tab Navigation */}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <span className="text-xl">{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Search Form */}
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-white font-medium flex items-center">
                <MapPin className="w-4 h-4 mr-2" />
                Destination
              </label>
              <input
                type="text"
                placeholder="Where to?"
                className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-cyan-400"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-white font-medium flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                Departure
              </label>
              <input
                type="date"
                className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-white font-medium flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                Return
              </label>
              <input
                type="date"
                className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-white font-medium flex items-center">
                <Users className="w-4 h-4 mr-2" />
                Guests
              </label>
              <select className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white focus:outline-none focus:ring-2 focus:ring-cyan-400">
                <option value="1">1 Guest</option>
                <option value="2">2 Guests</option>
                <option value="3">3 Guests</option>
                <option value="4">4+ Guests</option>
              </select>
            </div>
          </div>

          <div className="text-center">
            <Button 
              onClick={handleSearch}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-12 py-4 text-lg font-semibold rounded-full transform hover:scale-105 transition-all duration-300"
            >
              <Search className="w-5 h-5 mr-2" />
              Search {tabs.find(tab => tab.id === activeTab)?.label}
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SearchSection;