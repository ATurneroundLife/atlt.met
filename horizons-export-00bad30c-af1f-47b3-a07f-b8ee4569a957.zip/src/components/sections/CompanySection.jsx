import React from 'react';
import { motion } from 'framer-motion';
import { Award, Users, Globe, Heart } from 'lucide-react';
const CompanySection = () => {
  const stats = [{
    icon: Users,
    number: '10,000+',
    label: 'Happy Travelers'
  }, {
    icon: Globe,
    number: '150+',
    label: 'Destinations'
  }, {
    icon: Award,
    number: '15+',
    label: 'Years Experience'
  }, {
    icon: Heart,
    number: '98%',
    label: 'Satisfaction Rate'
  }];
  return <section id="company" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div initial={{
        opacity: 0,
        y: 50
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} className="text-center mb-16">
          <h2 className="text-5xl font-bold text-white mb-6">Our Company</h2>
          <p className="text-xl text-cyan-200 max-w-3xl mx-auto">
            ATurneroundLife Travel LLC is dedicated to transforming your travel dreams into extraordinary realities.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div initial={{
          opacity: 0,
          x: -50
        }} whileInView={{
          opacity: 1,
          x: 0
        }} transition={{
          duration: 0.8
        }}>
            <img alt="Professional travel consultants helping clients" className="w-full h-96 object-cover rounded-2xl" src="https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3" />
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          x: 50
        }} whileInView={{
          opacity: 1,
          x: 0
        }} transition={{
          duration: 0.8
        }} className="space-y-6">
            <h3 className="text-3xl font-bold text-white">Why Choose ATurneroundLife Travel?</h3>
            <p className="text-cyan-200 text-lg leading-relaxed">
              With over 15 years of experience in the travel industry, we specialize in creating 
              personalized travel experiences that exceed expectations. Our team of expert travel 
              consultants works tirelessly to ensure every detail of your journey is perfect.
            </p>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                <span className="text-white">Personalized travel planning</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                <span className="text-white">24/7 customer support</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                <span className="text-white">Exclusive travel deals</span>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {stats.map((stat, index) => <motion.div key={stat.label} initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.6,
          delay: index * 0.1
        }} className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 text-center">
              <stat.icon className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
              <div className="text-4xl font-bold text-white mb-2">{stat.number}</div>
              <div className="text-cyan-200">{stat.label}</div>
            </motion.div>)}
        </div>
      </div>
    </section>;
};
export default CompanySection;