import React from 'react';
import { motion } from 'framer-motion';
import { Facebook, Instagram, Twitter, Youtube, Linkedin } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const SocialSection = () => {
  const handleSocialClick = (url) => {
    if (url) {
      window.open(url, '_blank');
    } else {
      toast({
        title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
      });
    }
  };

  const socialPlatforms = [
    {
      icon: Facebook,
      name: 'Facebook',
      description: 'Follow us for travel inspiration and exclusive deals',
      color: 'from-blue-600 to-blue-700',
      followers: '25K+',
      url: 'https://www.facebook.com/profile.php?id=100086778344616'
    },
    {
      icon: Instagram,
      name: 'Instagram',
      description: 'Beautiful travel photos and destination highlights',
      color: 'from-pink-500 to-purple-600',
      followers: '18K+',
      url: 'https://www.instagram.com/aturneroundlife/'
    },
    {
      icon: Twitter,
      name: 'Twitter',
      description: 'Latest travel news and quick updates',
      color: 'from-blue-400 to-blue-500',
      followers: '12K+',
      url: 'https://x.com/aturneroundlife'
    },
    {
      icon: Youtube,
      name: 'YouTube',
      description: 'Travel vlogs and destination guides',
      color: 'from-red-500 to-red-600',
      followers: '8K+',
      url: 'https://www.youtube.com/@aturneroundlife'
    },
    {
      icon: Linkedin,
      name: 'LinkedIn',
      description: 'Professional travel industry insights',
      color: 'from-blue-700 to-blue-800',
      followers: '5K+',
      url: 'https://www.linkedin.com/in/donald-l-turner-jr-720a5b1a/'
    },
    {
      customIcon: 'https://horizons-cdn.hostinger.com/00bad30c-af1f-47b3-a07f-b8ee4569a957/e0059b6adbd3ae9b0cf2584f478c8106.png',
      name: 'TikTok',
      description: 'Short-form travel videos and fun content',
      color: 'from-black to-gray-700',
      followers: 'New!',
      url: 'http://tiktok.com/@aturneroundlife'
    }
  ];

  return (
    <section id="social" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-white mb-6">Follow Us on Social</h2>
          <p className="text-xl text-cyan-200 max-w-3xl mx-auto">
            Stay connected with us for travel inspiration, exclusive deals, and amazing destination content.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {socialPlatforms.map((platform, index) => (
            <motion.div
              key={platform.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => handleSocialClick(platform.url)}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 hover:border-white/40 transition-all duration-300 cursor-pointer"
            >
              <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${platform.color} flex items-center justify-center mb-6 mx-auto`}>
                {platform.icon ? (
                  <platform.icon className="w-8 h-8 text-white" />
                ) : (
                  <img src={platform.customIcon} alt={`${platform.name} logo`} className="w-8 h-8" />
                )}
              </div>
              <h3 className="text-2xl font-bold text-white mb-2 text-center">{platform.name}</h3>
              <p className="text-cyan-200 text-center mb-4">{platform.description}</p>
              <div className="text-center">
                <span className="text-white font-semibold">{platform.followers} followers</span>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 text-center"
        >
          <h3 className="text-3xl font-bold text-white mb-4">Join Our Travel Community</h3>
          <p className="text-xl text-cyan-200 mb-6 max-w-2xl mx-auto">
            Be part of our growing community of travel enthusiasts. Share your experiences, 
            get travel tips, and discover new destinations with fellow travelers.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {socialPlatforms.map((platform) => (
              <button
                key={platform.name}
                onClick={() => handleSocialClick(platform.url)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-full bg-gradient-to-r ${platform.color} text-white font-semibold hover:scale-105 transition-all duration-300`}
              >
                {platform.icon ? (
                  <platform.icon className="w-5 h-5" />
                ) : (
                  <img src={platform.customIcon} alt={`${platform.name} logo`} className="w-5 h-5" />
                )}
                <span>Follow</span>
              </button>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SocialSection;