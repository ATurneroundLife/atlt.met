import React from 'react';
import { motion } from 'framer-motion';
import { Building, Plane, Ship, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const AffiliatesSection = () => {
  const handlePartnerClick = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const partners = [
    {
      name: 'Global Airways',
      icon: Plane,
      color: 'from-blue-400 to-blue-500',
    },
    {
      name: 'Luxury Cruise Lines',
      icon: Ship,
      color: 'from-cyan-400 to-teal-500',
    },
    {
      name: 'Exquisite Hotels Group',
      icon: Building,
      color: 'from-purple-400 to-indigo-500',
    },
    {
      name: 'Adventure Tours Inc.',
      icon: Star,
      color: 'from-yellow-400 to-orange-500',
    },
  ];

  return (
    <section id="affiliates" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/50 to-blue-900/50"></div>
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-white mb-6">Our Trusted Partners</h2>
          <p className="text-xl text-cyan-200 max-w-3xl mx-auto">
            We partner with the best in the industry to bring you unparalleled travel experiences.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {partners.map((partner, index) => (
            <motion.div
              key={partner.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              whileHover={{ scale: 1.1, y: -10 }}
              onClick={handlePartnerClick}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 text-center cursor-pointer"
            >
              <div className={`w-20 h-20 rounded-full bg-gradient-to-r ${partner.color} flex items-center justify-center mb-4 mx-auto`}>
                <partner.icon className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white">{partner.name}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AffiliatesSection;