import React, { useEffect } from 'react';

const FacebookMessengerChat = ({ pageId }) => {
  useEffect(() => {
    const setupFacebookMessenger = () => {
      if (document.getElementById('facebook-jssdk')) {
        if (window.FB) {
          window.FB.XFBML.parse();
        }
        return;
      }

      window.fbAsyncInit = function() {
        window.FB.init({
          xfbml: true,
          version: 'v19.0'
        });
      };

      const script = document.createElement('script');
      script.id = 'facebook-jssdk';
      script.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
      script.async = true;
      script.defer = true;
      document.body.appendChild(script);
    };

    setupFacebookMessenger();

    return () => {
      const script = document.getElementById('facebook-jssdk');
      if (script) {
        // It's generally better to leave the script in place,
        // but this is here in case of cleanup needs.
      }
    };
  }, []);

  return (
    <>
      <div id="fb-root"></div>
      <div 
        id="fb-customer-chat" 
        className="fb-customerchat"
        attribution="biz_inbox"
        page_id={pageId}
      >
      </div>
    </>
  );
};

export default FacebookMessengerChat;