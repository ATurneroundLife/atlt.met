import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const scrollToSection = (sectionId, path) => {
    setIsMenuOpen(false);
    if (path) {
      navigate(path);
      return;
    }
    
    if (location.pathname !== '/') {
      navigate(`/#${sectionId}`);
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const navItems = [
    { name: 'Home', section: 'hero' },
    { name: 'Travel', section: 'search' },
    { name: 'Contact Us', section: 'contact' },
    { name: 'Social Media', section: 'social' },
    { name: 'Affiliates', section: 'affiliates' },
    { name: 'Customer Login', path: '/customer-login', section: 'customer-login' }
  ];

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="fixed top-0 left-0 right-0 z-50 bg-white/10 backdrop-blur-lg border-b border-white/20"
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-3">
            <img 
              src="https://horizons-cdn.hostinger.com/00bad30c-af1f-47b3-a07f-b8ee4569a957/10ec0eb08b8c8d6abd2adcd055d511e5.png" 
              alt="ATurneroundLife Travel LLC Logo" 
              className="h-12 w-auto"
            />
            <div className="text-white">
              <h1 className="text-xl font-bold">ATurneroundLife</h1>
              <p className="text-sm text-cyan-200">Travel LLC</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => scrollToSection(item.section, item.path)}
                className="text-white hover:text-cyan-300 transition-colors duration-300 font-medium"
              >
                {item.name}
              </button>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white p-2"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden mt-4 pb-4"
          >
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => scrollToSection(item.section, item.path)}
                className="block w-full text-left text-white hover:text-cyan-300 transition-colors duration-300 py-2 font-medium"
              >
                {item.name}
              </button>
            ))}
          </motion.nav>
        )}
      </div>
    </motion.header>
  );
};

export default Header;