import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <motion.footer
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="bg-white/10 backdrop-blur-lg border-t border-white/20 py-12 mt-20"
    >
      <div className="container mx-auto px-4 text-center text-white">
        <div className="mb-8">
          <Link to="/" className="flex items-center justify-center space-x-3 mb-4">
            <img 
              src="https://horizons-cdn.hostinger.com/00bad30c-af1f-47b3-a07f-b8ee4569a957/10ec0eb08b8c8d6abd2adcd055d511e5.png" 
              alt="ATurneroundLife Travel LLC Logo" 
              className="h-10 w-auto"
            />
            <div className="text-white">
              <h3 className="text-xl font-bold">ATurneroundLife</h3>
              <p className="text-sm text-cyan-200">Travel LLC</p>
            </div>
          </Link>
          <p className="text-cyan-200 max-w-2xl mx-auto">
            Your trusted partner in creating unforgettable travel experiences.
          </p>
        </div>

        <div className="mb-8">
          <h4 className="text-lg font-semibold text-white mb-4">Seller of Travel Numbers</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-cyan-200">
            <p>California: #2073234-00</p>
            <p>Florida: ST36257</p>
            <p>
              Hawaii: <a href="http://cca.hawaii.gov/pvl/programs/travel/" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline">Hawaii Seller of Travel</a>
            </p>
            <p>Iowa: #924</p>
            <p>Washington: #602864166</p>
          </div>
        </div>
        <div className="border-t border-white/20 pt-8">
          <p className="text-sm text-cyan-300">&copy; {new Date().getFullYear()} ATurneroundLife Travel LLC. All rights reserved.</p>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;